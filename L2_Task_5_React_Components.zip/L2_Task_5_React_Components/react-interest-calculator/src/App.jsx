import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import BalanceDisplay from "./components/BalanceDisplay";
import TransactionControls from "./components/TransactionControls";
import InterestFeeControls from "./components/InterestFeeControls";

function App() {
  const [balance, setBalance] = useState(1000);

  const handleDeposit = (amount) => {
    if (!isNaN(amount) && amount > 0) {
      setBalance(balance + amount);
    }
  };

  const handleWithdraw = (amount) => {
    if (!isNaN(amount) && amount > 0) {
      setBalance(balance - amount);
    }
  };

  const applyInterest = (rate) => {
    setBalance(balance + (balance * (rate / 100)));
  };

  const chargeBankFee = (rate) => {
    setBalance(balance - (balance * (rate / 100)));
  };

  return (
    <div className="container mt-5">
      <h2 className="text-center">Bank Account</h2>
      <BalanceDisplay balance={balance} />
      {/* passes handle Deposit and handle Withdrawal to Transaction controls */}
      <TransactionControls onDeposit={handleDeposit} onWithdraw={handleWithdraw} />
        {/* passes apply Interest and charge Fee to Interest Fee controls */}
      <InterestFeeControls onApplyInterest={applyInterest} onChargeFee={chargeBankFee} />
    </div>
  );
}

export default App;

