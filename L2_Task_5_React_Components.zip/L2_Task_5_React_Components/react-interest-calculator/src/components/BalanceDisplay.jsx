import React from "react";

function BalanceDisplay({ balance }) {
  return (
    <div>
      <h4 className={balance < 0 ? "text-danger" : "text-success"}>
        Balance: £{balance.toFixed(2)}
      </h4>
      {balance < 0 && <div className="alert alert-danger">Warning: Your balance is negative!</div>}
    </div>
  );
}

export default BalanceDisplay;