import React, { useState } from "react";

function InterestFeeControls({ onApplyInterest, onChargeFee }) {
  const [interestRate, setInterestRate] = useState(5);
  const [feeRate, setFeeRate] = useState(2);

  return (

    <div>
        <hr/>
      <div className="mb-3">
    
        <button className="btn btn-info mt-2" onClick={() => onApplyInterest(interestRate)}>
          Add 5% Interest
        </button>
        
      </div>
      <div className="mb-3">
    
        <button className="btn btn-danger mt-2" onClick={() => onChargeFee(feeRate)}>
        2% Fee Charge
        </button>
      </div>
    </div>
  );
}

export default InterestFeeControls;
