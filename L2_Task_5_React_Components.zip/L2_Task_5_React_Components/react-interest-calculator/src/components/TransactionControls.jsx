import React, { useState } from "react";

function TransactionControls({ onDeposit, onWithdraw }) {
  const [amount, setAmount] = useState("");

  return (
    <div className="mb-3">
      <input
        type="number"
        className="form-control"
        value={amount}
        onChange={(event) => setAmount(event.target.value)}
        placeholder="Enter amount"
      />
      <button className="btn btn-success mt-2" onClick={() => onDeposit(parseFloat(amount))}>
        Deposit
      </button>
      <button className="btn btn-warning mt-2 mx-2" onClick={() => onWithdraw(parseFloat(amount))}>
        Withdraw
      </button>
    </div>
  );
}

export default TransactionControls;
