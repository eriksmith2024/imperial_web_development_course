# React + Vite

<!-- 
https://www.youtube.com/watch?v=BBD2h-9CdVI Youtube React build a banking app Accessed 26th Feb 2025

https://www.youtube.com/watch?v=PuOVqP_cjkE Youtube React build a banking app Accessed 26th Feb 2025

https://www.youtube.com/watch?v=nZubt9c7WGc Youtube React build a banking app Accessed 26th Feb 2025

https://www.w3schools.com/bootstrap/bootstrap_alerts.asp W3 schools accessed 26th February 2025 in reference to bootstrap className

https://getbootstrap.com/docs/4.0/getting-started/webpack/ Bootstrap Webpack documentation accessed 26th February 2025 to utilize bootstrap rather than customized css or tailwind etc

https://www.w3schools.com/react/default.asp W3 schools React Tutorial Accessed 22nd Feb to 24th Feb 2025 - completed W3 Schools React course to help with understanding of react- need to complete test for certification 

https://www.youtube.com/watch?v=b9eMGE7QtTk Youtube Master React tutorial Accessed 22nd Feb 2025



-->

