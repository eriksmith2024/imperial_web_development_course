
<!-- 
Testing 
- 4 buttons added all utilising bootsrap styling - see json file below showing dependency for check on boostrap installation.
- Enter 100 and 0.50 Deposit correctly ammends the balance
- Enter 100 and 0.50 withdraw coorrectly deducts from the balance
- Enter 100 and utilise charge button correctly deducts 15% from balance leaving 85
- Enter 100 and utilised interest button corectly adding 5% to balance leaving 105


Hyperion dev Front End Development/L2T09 - React - Redux and Global State Management
/06-006-1 React - Redux and Global State Management.pdf Accessed 25th March 2025
https://www.youtube.com/watch?v=s2skans2dP4 Youtube react video - Accessed 25th March 2025
https://www.youtube.com/watch?v=kK_Wqx3RnHk Youtube react useReducer video Accessed 25th March 2025
https://www.youtube.com/watch?v=rgp_iCVS8ys&t=504s Youtube react on useReducer Accessed 25th March 2025
https://www.youtube.com/watch?v=kFe4h4HHpbA Youtube react video on Reducer using a bank account example Accessed 25th March 2025
https://www.youtube.com/watch?v=XuFDcZABiDQ Youtube video on expenses tracker using reducer Accessed 25th March 2025
https://stackoverflow.com/questions/53148972/best-way-to-setup-a-react-usereducer Stack Overflow Accessed 26th march 2025
https://www.youtube.com/watch?v=LOH1l-MP_9k&t=507s Youtube video on hooks explained Accessed 26th March 2025
https://dmitripavlutin.com/react-usereducer/ Article on useReducer Accessed 26th March 2025
https://react.dev/reference/react/useReducer React useReducer documents Accessed 26th March 2025
https://react-bootstrap.github.io/docs/components/buttons React Bootsrap docs Accessed 26th March 2025
https://chatgpt.com/c/67e406e8-9a38-8007-ad11-0341d6cd5f98 chat gpt dialogue regarding code fix Accessed 26th March 2025 -->

<!-- I read various documentation around the useReducer hook and basically see it as a global version of state management.I did struggle with this task and utilised youtube videos significantly. I struggled the with concept / theory of useReducer in contrast to redux which makes a lot more sense to me - I know it avoids prop drilling but struggled to see the benefit of it. It just felt like another version of useState and I could not really determine when it would be better to utilise it over useState. 

A lot of the documentation both the course material and the extra material I looked at went over my head with this task including looking at useContext. I did revisit youtube videos on the basics of react which was a useful refresher but when returning to the useContext and useReducer parts I could not fully grasp it.  It is an area I would like to discuss in a mentor meeting to help  my understanding & ability to utilise useReducer & useContext better.  -->


<!-- Related to feedback from last task Copy of the dependencies for this task showing boostrap 
{
  "name": "example-app",
  "version": "0.1.0",
  "private": true,
  "dependencies": {
    "@reduxjs/toolkit": "^2.6.1",
    "@testing-library/dom": "^10.4.0",
    "@testing-library/jest-dom": "^6.6.3",
    "@testing-library/react": "^16.2.0",
    "@testing-library/user-event": "^13.5.0",
    "bootstrap": "^5.3.3", SHOWS BOOTSRAP AS A DEPENDENCY TALEN FROM package.json file
    "react": "^19.0.0",
    "react-bootstrap": "^2.10.9",
    "react-dom": "^19.0.0",
    "react-redux": "^9.2.0",
    "react-scripts": "5.0.1",
    "web-vitals": "^2.1.4"
  }, -->