// Keep confusing with index.js when starting afresh.  App.js or App.jsx is the heart of the app where all components come together
// It manages the state and updates the UI User Interface i.e. can just keep adding button component at the bottom
import React, { useReducer, useState } from "react"; // Import React library, useReducer for managing state with a reducer function, and useState for basic state management
import "./App.css"; // Import custom CSS for styling the app 
import { balanceReducer, initialState } from "./store/balanceReducer"; // Import the reducer function and initial state from balanceReducer.js
import ButtonComponent from "./components/ButtonComponent"; // Import ButtonComponent to render buttons for actions
import AmountInput from "./components/AmountInput"; // Import AmountInput to allow user to enter amount
import BalanceDisplay from "./components/BalanceDisplay"; // Import BalanceDisplay to show current balance
import "bootstrap/dist/css/bootstrap.min.css"; // Import boostrap CSS

function App() {
  // useReducer hook manages state for the balance by using the balanceReducer function and the initialState.
  // It helps handle state changes like deposit and withdrawal actions.
  const [state, dispatch] = useReducer(balanceReducer, initialState);

  // useState hook manages the amount entered by the user.
  // It stores the value entered in the AmountInput field.
  const [amount, setAmount] = useState(""); // set to "" which allows the placeholder enter amount to show on load.

  // Track last transaction message for the amount added or deducted with interest and charges
  const [transactionMessage, setTransactionMessage] = useState("");

  return (
    // A div container with Bootstrap classes to style the app's layout
    <div className="container text-center mt-4"> 
      <h1>Account Balance</h1>

      {/* Display the current balance by passing the balance state to the BalanceDisplay component */}
      <BalanceDisplay balance={state.balance} />

      {/* Show transaction message for interest and charges*/}
      {transactionMessage && <p className="mt-2 text-muted">{transactionMessage}</p>}

      {/* Input field for entering the amount, passing amount and setAmount to handle input */}
      <AmountInput amount={amount} setAmount={setAmount} />

      {/* Button components for each action, passing different types of actions to the dispatch function */}
      <div className="d-flex justify-content-center gap-3 mt-3">
        <ButtonComponent 
          label="Deposit" 
          variant="success" 
          onClick={() => dispatch({type: "DEPOSIT", amount})} // Calls dispatch to deposit the entered amount
        />
        <ButtonComponent 
          label="Withdraw" 
          variant="danger" 
          onClick={() => dispatch({type: "WITHDRAW", amount})} // Calls dispatch to withdraw the entered amount
        />
        <ButtonComponent 
          label="Account Interest 5%" 
          variant="info" 
          onClick={() => { //onClick triggers interest addition and message of deduction amount
            const interestAmount = state.balance * 0.05;  // Calculate 5% interest
            dispatch({ type: "ADD_INTEREST" }); // add the interest to balance with dispatch
            setTransactionMessage(`Interest Added: £${interestAmount.toFixed(2)}`); // display addition message
          }} 
        />
        <ButtonComponent 
          label="Account Charge 15%" 
          variant="warning" 
          onClick={() => {// onClick triggers the deduction and message of deduction amount
            const chargeAmount = state.balance * 0.15;  // Calculate 15% charge
            dispatch({ type: "CHARGES" });// minus the charges to balance with dispatch
            setTransactionMessage(`Charges Deducted: £${chargeAmount.toFixed(2)}`); // display deduction message
          }} 
        />
      </div>
    </div>
  );
}

export default App;

