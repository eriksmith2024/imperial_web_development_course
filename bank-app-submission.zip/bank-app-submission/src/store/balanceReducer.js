// This file contains the the reducer function
// The reducer function updates the balance based on the user actions


const initialState = { balance: 0 }; // set starting balance

const balanceReducer = (state, action) => {
  switch (action.type) {
    case "DEPOSIT": // switch statement case with name of switch case
      return { balance: state.balance + action.amount }; // Add input amount which is action.amount
    case "WITHDRAW":// switch statement case with name of switch case
      return { balance: state.balance - action.amount }; // Deduct input amount which us action.amount
    case "ADD_INTEREST":// switch statement case with name of switch case
      return { balance: state.balance * 1.05}; // *(multiply) by 1.05 increase balance by 5% i.e. 105 of total
    case "CHARGES":// switch statement case with name of switch case
      return { balance: state.balance * 0.85 } // *(multiply by 0.85 reduce balance by 15% i.e. 0.85 of the total)
    default:
      return state; // default switch case if no matching action return the current balance  
  } 
};

export { initialState, balanceReducer}; // export statement that allows use in other files of the initialState variable 
// and also imports the balanceReducer function above again for use via import in other files.