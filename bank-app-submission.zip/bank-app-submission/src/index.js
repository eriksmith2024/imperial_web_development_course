// This file loads the app into the browser imported from App.js 
// It renders the app into the root element in the index.html file
// index.js
import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App"; 

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);



