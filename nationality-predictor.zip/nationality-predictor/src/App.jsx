import React, { useState, useEffect, useRef } from "react"; // import the required hooks
import "./index.css";

function App() {
  const [name, setName] = useState("");
  // name state variable to hold name entered by the user initially empty & setName to update the state
  const [country, setCountry] = useState(null);
  // country variable to store the country data fetched from the API & setCountry to update country state
  const [error, setError] = useState(null);
  // state variable to store any error messages for failed API requests
  const inputRef = useRef();
  // Reference to the input element

  // Function to Fetch nationality and country name
  const fetchNationality = async () => {
    if (!name) return; // Here so tries to fetch the API only once the name is entered

    // make API request normal await response from API etc & parse response
    try {
      const response = await fetch(`https://api.nationalize.io?name=${name}`);
      const data = await response.json();

      if (data.country && data.country.length > 0) {
        const countryCode = data.country[0].country_id;
        // If API contains country data access first country object country code with data.country[0]

        const countryResponse = await fetch(
          `https://restcountries.com/v3.1/alpha/${countryCode}`
        );
        const countryData = await countryResponse.json();
        // Make another API request with country code and parse full country details

        setCountry({
          name: countryData[0].name.common,
          probability: Math.round(data.country[0].probability * 100),
        });
        // update country state with full country name and probability
      } else {
        setError("No nationality data found.");
        setCountry(null);
      } // if no country data found reset country state setCountry
    } catch {
      setError("Error fetching nationality.");
    } // API error handling if an error occurs during request
  };

  // Auto-focus input field useEffect hook to run code after component mounts
  useEffect(() => inputRef.current.focus(), []); // Empty array so mounts once - see Hyp Dev sheet

  return (
    <div className="App">
      <h1>Nationality Predictor</h1>
      <input
        ref={inputRef}
        type="text"
        placeholder="Enter name"
        value={name}
        onChange={(e) => {
          setName(e.target.value);
          setError(null);
        }} // remember e is shorthand for event
      />
      <button onClick={fetchNationality}>Predict Nationality</button>

      {error && <p style={{ color: "red" }}>{error}</p>}

      {country && (
        <div>
          <h2>Predicted Nationality:</h2>
          <p>Country: {country.name}</p>
          {/* Only show probability if it's available */}
          {country.probability && ( // solution to show probability & country after name entered
            <p>Probability: {country.probability}%</p>
          )}
        </div>
      )}
    </div>
  );
}

export default App;
