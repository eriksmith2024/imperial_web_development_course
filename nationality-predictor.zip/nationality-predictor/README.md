# React + Vite

<!-- 
https://www.youtube.com/watch?v=xfKYYRE6-TQ Accessed 27th Feb 2025 - really useful with code along examples of hooks

https://github.com/hyperiondev-bootcamps/ES24110015904/blob/main/Level%202%20-%20Front%20End%20Development/L2T06%20-%20React%20-%20Hooks/06-005-1%20React%20-%20Hooks.pdf
Hyperion Dev React Hooks document Accessed 27th Feb 2025

https://www.youtube.com/watch?v=wIyHSOugGGw&t=126s Youtube Video Accessed 27th Feb 2025 - Explaining key react concepts i.e. hooks
https://www.youtube.com/watch?v=LOH1l-MP_9k Youtube Video Accessed 27th Feb 2025 - focus on hooks

https://www.youtube.com/watch?v=v_qzO_K7ffs&t=187s 
https://www.youtube.com/watch?v=XEnL3K4rSa4&t=1211s Youtube videos building Nationality Predictor Accessed 27th Feb 2025  

https://github.com/geshan/name-nationality-meticulous/blob/master/src/App.js GitHub repository for Nationality Predictor referenced Accessed 27th Feb 2025

-->