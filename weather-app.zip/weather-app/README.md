# React + Vite

<!-- Testing -
Initially when reopening had an issue with import not listing folder component. Should be resolved on submission. Along with node modules install 'npm install axios' for the app to work.

Tested with Liverpool Barcelona London - which showed correct data of location with country temp i.e. 7.4° in Liverpool & 8.3 in London with a condition and appropriate icon.

Entering Blur correctly triggered message of city not found please try again.
The .env file does not show in the folders when compressing for submission. I assume this is part of that files security.

In response to feedback on last assignment extensive notes included breaking down what each part of the code does.

References
https://github.com/hyperiondev-bootcamps/ES24110015904/tree/main/Level%202%20-%20Front%20End%20Development/L2T06%20-%20React%20-%20Hooks Accessed 26th Feb 2025 Hyp Dev LT06 React Hooks

https://www.youtube.com/watch?v=xfKYYRE6-TQ

https://www.weatherapi.com/

https://www.youtube.com/watch?v=zs1Nq2s_uy4 Accessed 27th Feb 2025

https://dev.to/vaatiesther/how-to-build-a-weather-app-in-react-48oj Dev Community
Accessed 28th Feb 2025

https://stackoverflow.com/questions/71050134/react-component-that-shows-the-current-weather-in-selected-city-temperature-de Stack overflow Accessed 28th Feb 2025

https://smartshock.hashnode.dev/create-a-weather-app-with-react-a-step-by-step-guide SmartShock Accessed 28th Feb 2025

https://www.freecodecamp.org/news/learn-react-by-building-a-weather-app/ free code camp weather building app - Accessed 28th Feb 2025

https://www.geeksforgeeks.org/weather-application-using-reactjs/ Geeks for Geeks Accessed 28th Feb 2025

https://devcommunity.io/en/articles/creating-and-testing-a-simple-weather-app-in-reactjs:-a-step-by-step-guide Dev Community building a react weather app step by step guide
 -->
