// Import necessary dependencies from React and external libraries
import React, { useState } from "react";
import axios from "axios"; // axios is a library for making HTTP requests

// Import child components for better modularity
import SearchForm from "./Components/SearchForm"; // Handles the input field and form submission
import WeatherInfo from "./components/WeatherInfo"; // Displays weather data when available
import ErrorMessage from "./components/ErrorMessage"; // Displays an error message if something goes wrong

// Define the main App component
const App = () => {
  // State variables to track user input, fetched weather data, and errors
  const [city, setCity] = useState(""); // Stores the name of the city entered by the user
  const [weatherData, setWeatherData] = useState(null); // Stores the weather data fetched from the API
  const [error, setError] = useState(""); // Stores any error messages to display

  // Fetch the API key from environment variables for security from
  const API_KEY = import.meta.env.VITE_API_KEY; // This prevents directly writing in API key as advised in Hyp dev docs

  // Function to update the city state when the user types into the input field
  const handleChange = (event) => {
    setCity(event.target.value); // Update the city state with the new input value
  };

  // Function to fetch weather data from the API
  const fetchWeatherData = async () => {
    if (city.trim() === "") return; // If the input is empty or only spaces, do nothing

    try {
      // Make a request to the weather API using axios
      const response = await axios.get(
        `http://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${city}&aqi=no`
      );

      // If the request is successful, store the received data in weatherData state
      setWeatherData(response.data);
      setError(""); // Clear any previous error messages
    } catch (err) {
      // If an error occurs (e.g., city not found), reset weatherData and set an error message
      setWeatherData(null);
      setError("City not found, please try again!");
    }
  };

  // Function to handle form submission
  const handleSubmit = (event) => {
    event.preventDefault(); // Prevent the default form submission behavior (which refreshes the page)
    fetchWeatherData(); // Call the function to get weather data
  };

  return (
    <div className="App">
      <h1>Weather App</h1>

      {/* Render the SearchForm component and pass necessary props */}
      <SearchForm city={city} onChange={handleChange} onSubmit={handleSubmit} />

      {/* If there's an error, display the ErrorMessage component */}
      {error && <ErrorMessage error={error} />}

      {/* If weather data is available, display the WeatherInfo component */}
      {weatherData && <WeatherInfo weatherData={weatherData} />}
    </div>
  );
};

// Export the App component so it can be used in other parts of the application
export default App;
