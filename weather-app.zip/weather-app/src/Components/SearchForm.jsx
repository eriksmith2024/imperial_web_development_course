// Define the SearchForm component that takes in three props: city, onChange, and onSubmit
const SearchForm = ({ city, onChange, onSubmit }) => {
  return (
    // Start of the form element where users can enter the city name
    <form onSubmit={onSubmit}>
      {" "}
      {/* When the form is submitted, it triggers the onSubmit function */}
      {/* Input field where users can type the city name */}
      <input
        type="text" // This makes the input field a text box
        placeholder="Enter city name" // This is the text inside the box when it's empty
        value={city} // The value of the input is set to the city prop (it displays the current city name)
        onChange={onChange} // When the user types, it triggers the onChange function to update the city name
      />
      {/* Submit button that users click to submit the form */}
      <button type="submit">Get Weather</button>{" "}
      {/* This button submits the form to get weather data */}
    </form>
  );
};

// Export the SearchForm component so it can be used in other parts of the application
export default SearchForm;
