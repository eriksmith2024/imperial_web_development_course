// Define a component called "ErrorMessage" that takes a prop named "error"
const ErrorMessage = ({ error }) => {
  // Return a paragraph <p> element that displays the error message
  // The text color is set to red to make the error stand out
  return <p style={{ color: "red" }}>{error}</p>;
};

// Export this component so it can be used in other parts of the app
export default ErrorMessage;

// error message is managed as state inside App.jsx const [error, setError] = useState('');
// // Line 41 App.jsx The setError function updates error when an error occurs in the fetchWeatherData function:
