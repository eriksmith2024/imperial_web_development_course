// This is a functional component called WeatherInfo that receives `weatherData` as a prop.
const WeatherInfo = ({ weatherData }) => {
  return (
    // This is a container div that will hold the weather information
    <div>
      {/* Display the name of the location (like a city or town) */}
      <h2>{weatherData.location.name}</h2>

      {/* Display the region (state or province) and country of the location */}
      <p>
        {weatherData.location.region}, {weatherData.location.country}
      </p>

      {/* Display the temperature in Celsius from the weather data */}
      <p>Temperature: {weatherData.current.temp_c}°C</p>

      {/* Display the current weather condition (like "Sunny", "Cloudy", etc.) */}
      <p>Condition: {weatherData.current.condition.text}</p>

      {/* Display an image icon that represents the weather condition */}
      {/* The `src` attribute gets the image URL from the condition icon */}
      <img
        src={`http://${weatherData.current.condition.icon}`} // Image URL is created dynamically
        alt={weatherData.current.condition.text} // Describes the weather condition in words for accessibility
      />
    </div>
  );
};

// Export the WeatherInfo component so it can be used in other parts of the application
export default WeatherInfo;
