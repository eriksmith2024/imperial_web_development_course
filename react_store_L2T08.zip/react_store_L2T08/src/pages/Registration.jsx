// https://formik.org/docs/overview Accessed 20th March 2025 for base structure of code
// https://formik.org/docs/overview Accessed 20th March 2025 for base structure of code
// https://codesandbox.io/p/sandbox/zKrK5YLDZ Accessed 20th March 2025
// Hyperion Dev React - Form Validation Accessed 20th March 2025
// I know we only required validation & not authentification but after doing a similar 
// task as part of a job application I wanted to add authentification. 
// Reason behind on task was 2 weeks on different aplication tasks & adding to website
// "Passed" both and also had interviews -  failed interviews seeking career support. 
// http://eriksmith.great-site.net/Login/index.html -  Accessed & Utilised learning from 
// this which is now also present on my personal website. 

import React, { useState } from 'react';
import { Formik, Form, useField } from 'formik';
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import * as Yup from 'yup';

const MyTextInput = ({ label, ...props }) => {
    const [field, meta] = useField(props);
    return (
        <div style={{ marginBottom: '10px' }}>
            <label htmlFor={props.id || props.name}>{label}</label>
            <input className="text-input" {...field} {...props} />
            {meta.touched && meta.error ? (
                <div className="error">{meta.error}</div>
            ) : null}
        </div>
    );
};

const MyCheckbox = ({ children, ...props }) => {
    const [field, meta] = useField({ ...props, type: 'checkbox' });
    return (
        <div style={{ marginBottom: '10px' }}>
            <label className="checkbox-input">
                <input type="checkbox" {...field} {...props} />
                {children}
            </label>
            {meta.touched && meta.error ? (
                <div className="error">{meta.error}</div>
            ) : null}
        </div>
    );
};

export const Registration = ({ onLoginStatusChange }) => {
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
            <div className="login-box" style={{ borderRadius: '8px' }}>
                <h1>Register</h1>
                <Formik
                    initialValues={{
                        firstName: '',
                        lastName: '',
                        email: '',
                        password: '',
                        reEnterPassword: '',
                        rememberMe: false,
                    }}
                    validationSchema={Yup.object({
                        firstName: Yup.string()
                            .max(15, 'Must be 15 characters or less')
                            .required('Required'),
                        lastName: Yup.string()
                            .max(20, 'Must be 20 characters or less')
                            .required('Required'),
                        email: Yup.string().email('Invalid email address').required('Required'),
                        password: Yup.string()
                            .min(8, 'Password must be at least 8 characters')
                            .matches(
                                /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/,
                                'Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character'
                            )
                            .required('Required'),
                        reEnterPassword: Yup.string()
                            .oneOf([Yup.ref('password'), null], 'Passwords must match')
                            .required('Required'),
                    })}
                    onSubmit={(values, { setSubmitting }) => {
                        setTimeout(() => {
                            alert(JSON.stringify(values, null, 2));
                            setSubmitting(false);
                        }, 400);

                        // Store email and password in localStorage
                        localStorage.setItem("registeredEmail", values.email);
                        localStorage.setItem("registeredPassword", values.password);
                        localStorage.setItem("userName", values.firstName + " " + values.lastName);

                        onLoginStatusChange(true);
                        navigate('/');
                    }}
                >
                    <Form>
                        <MyTextInput label="First Name" name="firstName" type="text" placeholder="First Name" />
                        <MyTextInput label="Last Name" name="lastName" type="text" placeholder="Last Name" />
                        <MyTextInput label="Email Address" name="email" type="email" placeholder="email@example.com" />
                        <div style={{ position: 'relative', marginBottom: '10px' }}>
                            <MyTextInput
                                label="Password"
                                name="password"
                                type={showPassword ? 'text' : 'password'}
                                placeholder="Password"
                            />
                            <button
                                type="button"
                                onClick={togglePasswordVisibility}
                                style={{
                                    position: 'absolute',
                                    right: '10px',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                }}
                            >
                                {showPassword ? 'Hide' : 'Show'}
                            </button>
                        </div>
                        <div style={{ position: 'relative', marginBottom: '10px' }}>
                            <MyTextInput
                                label="Confirm Password"
                                name="reEnterPassword"
                                type={showPassword ? 'text' : 'password'}
                                placeholder="Re-enter Password"
                            />
                            <button
                                type="button"
                                onClick={togglePasswordVisibility}
                                style={{
                                    position: 'absolute',
                                    right: '10px',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                }}
                            >
                                {showPassword ? 'Hide' : 'Show'}
                            </button>
                        </div>

                        <MyCheckbox name="rememberMe">Remember Me</MyCheckbox>
                        <button type="submit">Register</button>
                        <p>
                            Already have an account? <Link to="/Login">Login</Link>
                        </p>
                    </Form>
                </Formik>
            </div>
        </div>
    );
};