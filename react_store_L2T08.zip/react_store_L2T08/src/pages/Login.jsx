// https://formik.org/docs/overview Accessed 20th March 2025 for base structure of code
// https://formik.org/docs/overview Accessed 20th March 2025 for base structure of code
// https://codesandbox.io/p/sandbox/zKrK5YLDZ Accessed 20th March 2025
// Hyperion Dev React - Form Validation Accessed 20th March 2025
// I know we only required validation & not authentification but after doing a similar 
// task as part of a job application I wanted to add authentification. 
// Reason behind on task was 2 weeks on different aplication tasks & adding to website
// "Passed" both and also had interviews -  failed interviews seeking career support. 
// http://eriksmith.great-site.net/Login/index.html -  Accessed & Utilised learning from 
// this which is now also present on my personal website. 

import React, { useState, useEffect } from 'react';
import { Formik, Form, useField } from 'formik';
import "./Login.css";
import { Link, useNavigate } from "react-router-dom";
import * as Yup from 'yup';

const MyTextInput = ({ label, ...props }) => {
    const [field, meta] = useField(props);
    return (
        <div style={{ marginBottom: '10px' }}>
            <label htmlFor={props.id || props.name}>{label}</label>
            <input className="text-input" {...field} {...props} />
            {meta.touched && meta.error ? (
                <div className="error">{meta.error}</div>
            ) : null}
        </div>
    );
};

const MyCheckbox = ({ children, ...props }) => {
    const [field, meta] = useField({ ...props, type: 'checkbox' });
    return (
        <div style={{ marginBottom: '10px' }}>
            <label className="checkbox-input">
                <input type="checkbox" {...field} {...props} />
                {children}
            </label>
            {meta.touched && meta.error ? (
                <div className="error">{meta.error}</div>
            ) : null}
        </div>
    );
};

export const Login = ({ onLoginStatusChange }) => {
    const [showPassword, setShowPassword] = useState(false);
    const navigate = useNavigate();
    const [userName, setUserName] = useState("");
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        const storedUser = localStorage.getItem("userName");
        if (storedUser) {
            setUserName(storedUser);
            setIsLoggedIn(true);
        }
    }, []);

    const handleLogout = () => {
        setIsLoggedIn(false);
        setUserName("");
        localStorage.removeItem("userName");
        onLoginStatusChange(false);
    };

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword);
    };

    const handleCombinedLogin = (values, setSubmitting) => {
        if (userName.trim() !== "") {
            setIsLoggedIn(true);
            localStorage.setItem("userName", userName);
        }

        setTimeout(() => {
            alert(JSON.stringify(values, null, 2));
            setSubmitting(false);
        }, 400);

        onLoginStatusChange(true);
        navigate('/');
    };

    const getStoredCredentials = () => {
        const storedEmail = localStorage.getItem("registeredEmail");
        const storedPassword = localStorage.getItem("registeredPassword");

        return {
            email: storedEmail || '',
            password: storedPassword || '',
        };
    };

    const initialCredentials = getStoredCredentials();

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
            <div className="login-box" style={{ borderRadius: '8px' }}>
                <h1>Login</h1>
                <div className="login-section">
                    {isLoggedIn ? (
                        <h1>Welcome, {userName}!</h1>
                    ) : (
                        <input
                            type="text"
                            placeholder="Enter your name"
                            value={userName}
                            onChange={(e) => setUserName(e.target.value)}
                        />
                    )}
                </div>
                <Formik
                    initialValues={{
                        email: initialCredentials.email,
                        password: initialCredentials.password,
                        rememberMe: false,
                    }}
                    validationSchema={Yup.object({
                        email: Yup.string().email('Invalid email address').required('Required'),
                        password: Yup.string()
                            .min(8, 'Password must be at least 8 characters')
                            .matches(
                                /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*])(?=.{8,})/,
                                'Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character'
                            )
                            .required('Required'),
                    })}
                    onSubmit={(values, { setSubmitting }) => {
                        if (isLoggedIn) {
                            handleLogout();
                        } else {
                            if (values.email === localStorage.getItem("registeredEmail") &&
                                values.password === localStorage.getItem("registeredPassword")) {
                                handleCombinedLogin(values, setSubmitting);
                            } else {
                                alert("Incorrect Email or Password");
                                setSubmitting(false);
                            }
                        }
                    }}
                >
                    <Form>
                        <MyTextInput label="Email Address" name="email" type="email" placeholder="email@example.com" />
                        <div style={{ position: 'relative', marginBottom: '10px' }}>
                            <MyTextInput
                                label="Password"
                                name="password"
                                type={showPassword ? 'text' : 'password'}
                                placeholder="Password"
                            />
                            <button
                                type="button"
                                onClick={togglePasswordVisibility}
                                style={{
                                    position: 'absolute',
                                    right: '10px',
                                    top: '50%',
                                    transform: 'translateY(-50%)',
                                    background: 'none',
                                    border: 'none',
                                    cursor: 'pointer',
                                }}
                            >
                                {showPassword ? 'Hide' : 'Show'}
                            </button>
                        </div>

                        <MyCheckbox name="rememberMe">Remember Me</MyCheckbox>
                        <button type="submit">{isLoggedIn ? "Logout" : "Login"}</button>
                        <p>
                            Don't have an account? <Link to="/Registration">Register</Link>
                        </p>
                    </Form>
                </Formik>
            </div>
        </div>
    );
};