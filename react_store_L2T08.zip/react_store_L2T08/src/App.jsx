import './App.css';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { About } from './pages/About';
import { Registration } from './pages/Registration';
import { Login } from './pages/Login';
import { Contact } from './pages/Contact';
import { Home } from './pages/Home';
import { Products } from './pages/Products';
import { Cart } from './pages/Cart';
import { useState, useEffect } from 'react';

function App() {
  const [cart, setCart] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Initialize with false

  useEffect(() => {
    const storedUser = localStorage.getItem("userName");
    setIsLoggedIn(!!storedUser); // Update on mount and storage change
  }, []);

  const handleLoginStatusChange = (status) => {
    setIsLoggedIn(status); // Update isLoggedIn state
  };

  const ProtectedRoute = ({ children }) => {
    if (!isLoggedIn) {
      return <Navigate to="/Login" replace />;
    }
    return children;
  };

  return (
    <Router>
      <Routes>
        <Route element={<Layout cart={cart} setCart={setCart} />}>
          <Route path="/" element={<Home />} />
          <Route path="/Login" element={<Login onLoginStatusChange={handleLoginStatusChange} />} />
          <Route path="/Registration" element={<Registration onLoginStatusChange={handleLoginStatusChange} />} />
          <Route path="/Home" element={<Home />} />
          <Route path="/Products" element={<Products cart={cart} setCart={setCart} />} />
          <Route path="/About" element={<About />} />
          <Route path="/Contact" element={<Contact />} />
          <Route
            path="/Cart"
            element={
              <ProtectedRoute>
                <Cart cart={cart} setCart={setCart} />
              </ProtectedRoute>
            }
          />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;