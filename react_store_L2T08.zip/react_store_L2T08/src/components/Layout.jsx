import { Navbar } from "./Navbar";
import { Header } from "./Header";
import { Outlet, useLocation } from "react-router-dom";

export function Layout({ cart }) {
  const location = useLocation();
  const isHomePage = location.pathname === "/";
  const isLoggedIn = localStorage.getItem("userName") !== null; // Check for login status

  return (
    <>
      <Navbar />
      {isLoggedIn && !isHomePage && <Header cart={cart} />}
      <main>
        <Outlet />
      </main>
    </>
  );
}