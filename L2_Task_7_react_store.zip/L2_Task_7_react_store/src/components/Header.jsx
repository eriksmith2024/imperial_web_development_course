import React from "react";
import "./Header.css"; // Import the CSS file

export function Header({ cart }) {
  // Calculate total price and total items
  const totalItems = cart.length; // Use cart.length for total items
  const totalPrice = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <header className="header"> {/* Apply the header class */}
      <h1>EJS Gym Solutions</h1>
      <div>
        <h2><strong>🛒 {totalItems} Items - £{totalPrice}</strong></h2>
      </div>
    </header>
  );
}