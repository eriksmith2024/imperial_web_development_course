import { Navbar } from "./Navbar";
import { Header } from "./Header";
import { Outlet, useLocation } from "react-router-dom"; // Import useLocation

export function Layout({ cart }) {
  const location = useLocation(); // Get the current location

  // Check if the current path is the home page
  const isHomePage = location.pathname === "/";

  return (
    <>
      <Navbar />
      {!isHomePage && <Header cart={cart} />} {/* if not homepage apply Header page */}
      <main>
        <Outlet />
      </main>
    </>
  );
}