import "./Home.css"; // Import the CSS file
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import BarbellImage from "../../public/Barbell.jpg";

export function Home() {
    const [userName, setUserName] = useState("");
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        const storedUser = localStorage.getItem("userName");
        if (storedUser) {
            setUserName(storedUser);
            setIsLoggedIn(true);
        }
    }, []);

    const handleLogin = () => {
        if (userName.trim() !== "") {
            setIsLoggedIn(true);
            localStorage.setItem("userName", userName);
        }
    };

    const handleLogout = () => {
        setIsLoggedIn(false);
        setUserName("");
        localStorage.removeItem("userName");
    };

    return (
        <div className="home-container">
            <h1>Welcome to our gym solutions store</h1>

            <div className="login-section">
                {isLoggedIn ? (
                    <>
                        <h1>Welcome, {userName}!</h1>
                        <button onClick={handleLogout}>Logout</button>
                    </>
                ) : (
                    <>
                        <input
                            type="text"
                            placeholder="Enter your name"
                            value={userName}
                            onChange={(e) => setUserName(e.target.value)}
                        />
                        <button onClick={handleLogin} disabled={!userName.trim()}>
                            Login
                        </button>
                    </>
                )}
            </div>

            <img src={BarbellImage} alt="Barbell" className="barbell-image" />

            <div className="products-link">
                <Link to="/Products">
                    <button>View All Products</button>
                </Link>
            </div>
        </div>
    );
}