import React, { useState } from 'react';
import './App.css';

// user profile with details and shopping_cart included
const user = {
  name: 'Erik',
  surname: 'Smith',
  date_of_birth: '2000-26-12',
  address: '123 Happy Street, London, UK',
  email: 'eriksmith.happy@hotmail.com',
  mobile: '619-619-2005',
  profile_picture: '/profile-pic.jpg',
  shopping_cart: [
    { item: 'LFC Home Shirt', price: 100 },
    { item: 'LFC Match Football', price: 30 },
    { item: 'LFC Match Ticket Liverpool v Manchester Utd', price: 100 }
  ]
};

// Items available to select from
const availableItems = [
  { item: 'LFC Home Shirt', price: 100 },
  { item: 'LFC Away Shirt', price: 90 },
  { item: 'LFC Scarf', price: 15 },
  { item: 'LFC Keychain', price: 5 },
  { item: 'LFC Next Champions League Match Ticket Liverpool v Real Madrid', price: 150 },
  { item: 'LFC Mug', price: 10 },
  { item: 'LFC V Real Madrid Match Program', price: 10 },
  { item: 'LFC V Man Utd Match Program', price: 10 },
  { item: 'LFC Football', price: 30 },
  { item: 'LFC Next Premier League Match Ticket Liverpool v Manchester Utd', price: 100 }
];

// Items set to shopping_cart on load
function App() {
  const [userState, setUserState] = useState(user);

  // Add item to shopping_cart
  const addToShoppingCart = (item) => {
    const updatedUser = { ...userState, shopping_cart: [...userState.shopping_cart, item] };
    setUserState(updatedUser);
  };

  // Remove item from shopping_cart
  const removeFromShoppingCart = (index) => {
    const updatedCart = userState.shopping_cart.filter((_, i) => i !== index);
    const updatedUser = { ...userState, shopping_cart: updatedCart };
    setUserState(updatedUser);
  };

  // Calculate total items in shopping_cart
  const totalItems = userState.shopping_cart.length;

  // Calculate total price
  const totalPrice = userState.shopping_cart.reduce((total, item) => total + item.price, 0);

  return (
    <div className="App">
      {/* User Profile */}
      <div className="user-profile">
        <img src={userState.profile_picture} alt="Profile_Pic" className="profile-img" />
        <div className="profile-details">
          <h1>{userState.name} {userState.surname}</h1>
          <p><strong>Date of Birth:</strong> {userState.date_of_birth}</p>
          <p><strong>Address:</strong> {userState.address}</p>
          <p><strong>Email:</strong> {userState.email}</p>
          <p><strong>Mobile:</strong> {userState.mobile}</p>
        </div>

        {/* Shopping Cart Section */}
        <div className="shopping-cart">
          <h2 className="shopping-cart-title"> 
            <img src="/cart.png" alt="Cart" className="cart-icon" /> 
            <span>LFC Member Shopping Cart</span>
          </h2>
          {/* Total Items and Price */}
          <div className="totals"> 
            <p><strong>Total Items in Shopping Cart:</strong> {totalItems}</p>
            <p><strong>Total Price:</strong> £{totalPrice}</p>
          </div>
         
          <ul>
            {userState.shopping_cart.map((item, index) => (
              <li key={index}>
                <span>{item.item} : £{item.price}</span>
                <button onClick={() => removeFromShoppingCart(index)}>Remove</button>
              </li>
            ))}
          </ul>
         
        </div>

        {/* Available Items to Add */}
        <div className="available-items">
          <h2>Available Items</h2>
          <ul>
            {availableItems.map((item, index) => (
              <li key={index}>
                {item.item} : £{item.price}
                <button onClick={() => addToShoppingCart(item)}>Add to Shopping Cart</button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}

export default App;

/* 
REFERENCES
https://www.w3schools.com/REACT/default.asp W3 Schools React Accessed 10th -13th Feb 2025 - Currently working 
through React tutorial with W3 schools alongside Imperial College work 
file:///Users/eriksmith/Downloads/06-033_React%20%E2%80%93%20Elements.pdf hyp Dev React Elements Accessed 10th -13th Feb 2025
https://stackoverflow.com/questions/74740497/adding-items-to-cart-in-react-js Stack Overflow Accessed 13th Feb 2025
https://www.geeksforgeeks.org/shopping-cart-app-using-react/ geeks for geeks Accessed 10th Feb 2025
https://www.youtube.com/watch?v=E8lXC2mR6-k Youtube video explaining React files Accessed 13th Feb 2025
https://www.youtube.com/watch?v=f55qeKGgB_M Youtube beginners video - 13th Feb 2025
https://www.youtube.com/watch?v=U2Wltnv-doo&list=PLpPqplz6dKxW5ZfERUPoYTtNUNvrEebAR Accessed 12th Feb 2025 Youtube video beginners 

TESTING
Opens with initial 3 items in cart
Can remove items form initial cart
Can add items to initial cart
Number of items updates correctly
Total Amount updates correctly

REFLECTION
Initially I worked from the hyperion dev task Sheet for pseudocode, created initial user object & items list. I then utilized
different sites / videos I watched which had full code for a React shopping cart. My approach was to take bits of code from 
different places and try and style my own cart.

Not sure I like my final new style shopping cart or if I was supposed to keep it to a traditional format but I tried to create my 
own cart format to get familiar with the React & HTML / JS (JSX) code mix. Separate to this task submitted I plan to create a
normal more professional style cart copying out the code from one of the many videos I have seen.
*/