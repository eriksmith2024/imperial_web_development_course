import LandingPage from "./pages/LandingPage"

function App() {

  return (
    <div className="font-netflix font-medium">
      <LandingPage />
    </div>
  )
}

export default App
