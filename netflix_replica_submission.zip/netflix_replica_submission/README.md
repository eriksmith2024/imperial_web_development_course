# React + Vite

<!-- 
Most of the challenge with this came with installing packages from create react app to Vite and tailwind with constant problems with dependencies. Spent days trying to sort this playing with terminal installing older versions, manually writing in the file when tailwind.config.js would not install etc to try and get tailwind compatible with vite. 

https://www.youtube.com/watch?v=89NJdbYTgJ8&t=73s Youtube video Accessed 18th Feb 2025 - install / create react with vite
https://www.youtube.com/watch?v=M1GS1SaxAiY Youtube video Accessed 18th Feb 2025 - install / create react with vite
https://www.youtube.com/watch?v=5Fl2dbAk6OE Youtube video Accessed 19th Feb 2025 Great video explaining components.
https://www.youtube.com/watch?v=sHnG8tIYMB4 Accessed Tailwind docs Accessed 20th Feb 2025.
https://tailwindcss.com/docs/installation/using-vite Tailwind docs Accessed 20th Feb 2025
https://tailwindcss.com/docs/installation/using-vite Tailwind docs Accessed 20th Feb 2025
https://www.youtube.com/watch?v=RrKA_NDvdgI Youtube video Accessed 20th Feb 2025 
https://github.com/saintlypioneer/netflix-clone/tree/main/Netflix-ReactJS/client/public GitHub had to access for images media and fonts. 
https://www.youtube.com/watch?v=yMPoFJ_CTUQ Youtube video Accessed 21st Feb 2025
https://www.youtube.com/watch?v=jXJ4hlaZAzY Youtube video Accessed 21st Feb 2025
https://www.youtube.com/watch?v=jTHPIGY5Pok Youtube video Accessed 21st Feb 2025
followed to develop the netflix clone. 
https://github.com/saintlypioneer/netflix-clone/tree/main/Netflix-ReactJS/client/src/componentsAfter coding alongside videos 1-4 Videos 4-8 were missing so had to access the Github repository to gain the code for the remaining components. Required understanding of components and how they are loaded via landing page to complete & renaming media etc so that it all worked.

https://chatgpt.com/c/67b87a94-60c8-8007-a1b9-5c5e8b07619f Chat GPT Accessed 21st Feb 2025 issue explanation 
https://chatgpt.com/c/67b87c08-0e20-8007-81ef-b31aaed888f9 Chat GPT Accessed 21st Geb 2025 issue fix - missed that a folder was in the GitHub repository and was trying to solve the issue myself in one file instead of importing.
https://chatgpt.com/c/67b87f67-09f8-8007-be75-7201b5efa7d1 Chat GPT explanation Accessed 21st Feb 2025


Testing 
all media played correctly and everything responded and resized with the screen.
 -->

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh
