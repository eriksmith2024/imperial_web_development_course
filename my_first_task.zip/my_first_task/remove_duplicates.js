// Import lodash
const lodash = require('lodash');// 

// Create the array
const numbers = [1, 2, 10, 100, 10, 2, 5, 6, 10, 1000, 7, 2, 100, 1, 5, 7, 10];

// Remove duplicates using lodash's uniq function
const uniqueNumbers = lodash.uniq(numbers);// looking at lodash file logically you use lodash.trimEnd for example to use a function

// Print the result
// console.log("Original Array:", numbers); //Task only wanted array with duplicates but I added this to compare and check.
console.log("Array without duplicates:", uniqueNumbers);

// used -rf node_modules to delete the node_modules files from the terminal rather than the user interface folder

/* 
Basically referred to the prior instructions for my_first_module just for my_first_task although used touch filename 
on the terminal to create the file
Hyperion L2T01 Node.js Accessed 7th Feb 2025. 
https://github.com/hyperiondev-bootcamps/ES24110015904/blob/main/Level%202%20-%20Front%20End%20Development/L2T01%20-%20NodeJS/11-033-2%20NodeJS.pdf


Needed help on the 2nd to last bullet point for using lodash to print the array with duplicates removed so referred to 
gemini ai. Link below accessed 7th Feb 2025. From reading & looking at lodash file logically you use lodash.trimEnd for example to use a function
https://gemini.google.com/app/bfa4440264f3e9ad?is_sa=1&is_sa=1&android-min-version=301356232&ios-min-version=322.0&campaign_id=bkws&utm_source=sem&utm_source=google&utm_medium=paid-media&utm_medium=cpc&utm_campaign=bkws&utm_campaign=2024enGB_gemfeb&pt=9008&mt=8&ct=p-growth-sem-bkws&gad_source=1&gclid=Cj0KCQiA-5a9BhCBARIsACwMkJ7ZFxjdyyQoYszKpi5f2QWozCmEJNUk-FrpaKIPaszUOxpv0Er3qYIaAvcWEALw_wcB&gclsrc=aw.ds */