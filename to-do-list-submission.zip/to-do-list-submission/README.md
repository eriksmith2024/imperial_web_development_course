<!-- 
Testing 
- Initial state based on code structure specified in task set in todoSlice.js which also includes all requested reducers
- All requested ui features appear on app start i.e. info icon heading and app name add to do button etc
- Each to do task item has styled buttons using icons to add edit delete and comple checkbox
- Can add tasks as specified with modal from components including warning message there if empty characters.
- info icon has pop up above all other content with instructions for use and close button
- UI includes display of number of items which ammends for added or deleted to do items
- scroll feature for to do list means it stays fixed on screen always visible
- when completed to do item fades out 
- completed to dos cannot be edited incomplete ones can. 

My app was based around the following youtube video and adapted to the task criteria. In response to last task feedback comprehensive notes have been provided. Also as the task was a difficult one and needed notes for reminding me around how it all works. 

Most of the challenge with this came with installing packages - althought following the correct documentation - Tailwind would not install. In seeking help from ai on the issue it confirmed my commands should install it and I must not have the privaleges. It recommended the command diskutil resetUserPermissions / $(id -u) which would reset the permissions which seemed like a reasonabkle solution. That or somethung else in the chat effectively broke my computer making it so I was unable to delete or access files in my folders. Effectively cutting me off from Apple cloud. 

On consulting a friend and looking at the activiuty monitor approach was to leave it on so whatever task the computer was doing would complete. It allowed me to access some files by doing this but not all. Could now work on my vsc and complete the second exercise but need to do a reset on the comnputer with apple after completing a external drive back up. Has led to a bit of confidence crisis. 

My friend who I sought help from that runs his own tech business and coded from the age of 7 was a bit dismissive of my knowledge including around the hardware elements which he was critical I should have better knowledge of. I have read books on computers how they work as the starting point before commencing on coding. The whole issue basically took up days and left me with a feeling I should give up and return to my old role. 

After the day the issue occured I did calm down and seek out a logical approach but it was still a painful experience. It helped by my friend admitting he had broken lots of computers over the years and his staff regularly come to him with a crisis. I had the same isues last time trying to install tailwind which were in my notes. After I calmed down went with a logical workaround to copy and paste the old files where I had applied tailwind successfully and ammend that react vite app. 

There is still an underlying issue with my mac that while I can do work the mac operates slowly and random files are not accessible.  I am going to back up my data and wipe my mac with apple follwing submission of coursework. 



Germini ai chat around tailwind installation issues Accessed 27th March 2025
https://gemini.google.com/app/64ad092e8112fbd9?is_sa=1&is_sa=1&android-min-version=301356232&ios-min-version=322.0&campaign_id=bkws&utm_source=sem&utm_source=google&utm_medium=paid-media&utm_medium=cpc&utm_campaign=bkws&utm_campaign=2024enGB_gemfeb&pt=9008&mt=8&ct=p-growth-sem-bkws&gad_source=1&gclid=Cj0KCQjwkZm_BhDrARIsAAEbX1EBLVb6eLvn8vuqWX9BGJGNrOW8FOIZeqb_YYvioL01PdR1tpclLeoaAs5oEALw_wcB&gclsrc=aw.ds

Gemini ai chat around tailwind installation issues Accesed 27th March 2025
https://gemini.google.com/app/c6a257b67606c7f1?is_sa=1&is_sa=1&android-min-version=301356232&ios-min-version=322.0&campaign_id=bkws&utm_source=sem&utm_source=google&utm_medium=paid-media&utm_medium=cpc&utm_campaign=bkws&utm_campaign=2024enGB_gemfeb&pt=9008&mt=8&ct=p-growth-sem-bkws&gad_source=1&gclid=Cj0KCQjwkZm_BhDrARIsAAEbX1EBLVb6eLvn8vuqWX9BGJGNrOW8FOIZeqb_YYvioL01PdR1tpclLeoaAs5oEALw_wcB&gclsrc=aw.ds

Hyperion Dev L2T09 React - Redux and Global State Management.pdf Accessed 23rd March 2025 
https://youtu.be/fEWzDX7BuwU Youtube Video Accessed 26th March 2025
https://youtu.be/fiesH6WU63I Youtube Video Accessed 26th March 2025
https://youtu.be/YhgSuUkWlK4 Youtube Video Accessed 26th March 2025
https://www.youtube.com/watch?v=fEWzDX7BuwU&t=608s Accessed 26th March 2025
https://redux-toolkit.js.org/ Redux toolkit Acccessed 28th March 
https://chatgpt.com/c/67e68dbc-0f04-8007-84dd-6a6d11887c1b Chat GPT Accessed 28th March 2025 for big fix around react icon import 
https://react-bootstrap.github.io/docs/components/modal/ Accessed 28th March 2025
https://chatgpt.com/c/67e6ed1f-ba58-8007-b069-ef8a7f9108e3 Chat GPT Accessed 28th March 2025 - adaptations around the modal
https://chatgpt.com/c/67e6b82d-1c14-8007-a6b1-9aa2827c7c17 Chat GPT Accessed 28th March 2025 for debugging

Hyperion dev Front End Development/L2T09 - React - Redux and Global State Management
/06-006-1 React - Redux and Global State Management.pdf Accessed 26th March 2025

https://redux.js.org/tutorials/fundamentals/part-5-ui-react Accessed 26th March 2025

in package.json files showed boostrap and redux installed as dependencies along with bootsrap
  },
  "dependencies": {
    "@popperjs/core": "^2.11.8",
    "@reduxjs/toolkit": "^2.6.1",
    "bootstrap": "^5.3.3",
    "react": "^19.0.0",
    "react-bootstrap": "^2.10.9",
    "react-dom": "^19.0.0",
    "react-icons": "^5.5.0",
    "react-redux": "^9.2.0"
  },
  "devDependencies": {
    "@eslint/js": "^9.19.0",
    "@types/react": "^19.0.8",
    "@types/react-dom": "^19.0.3",
    "@vitejs/plugin-react-swc": "^3.5.0",
    "autoprefixer": "^10.4.20",
    "eslint": "^9.19.0",
    "eslint-plugin-react": "^7.37.4",
    "eslint-plugin-react-hooks": "^5.0.0",
    "eslint-plugin-react-refresh": "^0.4.18",
    "globals": "^15.14.0",
    "postcss": "^8.5.3",
    "tailwindcss": "^3.4.17",
    "vite": "^6.1.0"
  }
}

-->


