// Import the necessary functions from Redux Toolkit
import { configureStore } from "@reduxjs/toolkit";
// Import the todoSlice reducer which will manage the to-do state
import todoReducer from "./features/todo/todoSlice";

// Create and configure the Redux store with the todoSlice reducer
const store = configureStore({
  reducer: {
    todos: todoReducer, // Assign the reducer to the to-dos slice of the state
  },
});

// Export the store to be used in the app
export default store;


// configureStore: This is a Redux Toolkit function that simplifies the process of creating a Redux store. 
// It automatically sets up Redux DevTools and other necessary configurations.

// todoReducer: This is the reducer imported from todoSlice.js. The reducer handles actions related to 
// the to-do list, such as adding, deleting, updating, and toggling the to-dos. It is the logic behind 
// the state updates for the todos slice.

// reducer: { todos: todoReducer }: This part of the code assigns the todoReducer to the to-dos slice of 
// the state. The to-dos slice will manage the to-do state, meaning the todoReducer will control how the 
// to-dos are added, deleted, or updated in the global state.

// In the todoSlice.js file, actions like todoAdded, todoDeleted, and todoToggled are dispatched to update 
// the to-do list. These actions will automatically trigger the appropriate state changes in this todos slice, 
// thanks to the todoReducer connected to this slice of the state.

// store: The store created here is an instance of the Redux store, which is a central object that holds 
// the application’s state. The store is configured with the todoReducer and any other reducers I might add. 
// The todos state managed by todoReducer will be part of the global state.

// export default store: This line exports the store so it can be used in other parts of the application. 
// Typically, this store will be passed to the Provider component from the react-redux library in the App.js 
// or index.js file. This makes the store available to all components in the app, allowing them to access 
// the state and dispatch actions.

// How it Works with Other Files:
// todoSlice.js: The todoReducer in todoSlice.js handles the state changes for to-dos. It listens for dispatched 
// actions (like todoAdded or todoDeleted) and updates the todos slice of the state accordingly.

// Redux Store: The store.js file configures the Redux store, where the todos state is managed using the todoReducer. 
// This store will be imported into the main React file (e.g., index.js), and the state it contains will be made 
// available to the components through the Provider from react-redux.

// React Components: In files like SingleTodoCard.jsx, AddToDoForm.jsx, or others, use useDispatch to dispatch 
// actions like todoAdded, todoDeleted, or todoToggled to modify the state. Also use useSelector to access the 
// todos slice of the state and render the list of to-dos.