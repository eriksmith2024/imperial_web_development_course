// Importing the necessary functions from Redux Toolkit
import { createSlice, nanoid } from "@reduxjs/toolkit"; 
// createSlice allows us to define reducers and actions in one place
// nanoid generates unique IDs for new to-dos, ensuring each one has a unique identifier

// Initial state of the to-dos in the app
const initialState = {
  // list holds the to-dos in the app
  list: [
    { id: nanoid(), content: "Complete Assignment", completed: false }, 
    { id: nanoid(), content: "Resolve mac issues", completed: false },
  ],
  // toggleForm is a flag that controls the visibility of the form
  toggleForm: true,
  // todoUpdate is used to store the to-do that is being edited (it will be populated when a to-do is selected for editing)
  todoUpdate: {},
};

// This is the todoSlice where all the state management happens for to-dos
export const todoSlice = createSlice({
  // Name for this slice of state, used in debugging and Redux dev tools
  name: "todo",
  // Define the initial state of the slice
  initialState,
  // Reducers define how the state changes based on dispatched actions
  reducers: {
    // Action and reducer that adds a new to-do to the list
    todoAdded: (state, action) => {
      // Adds a new to-do with a unique ID and content from the payload
      state.list = [...state.list, { id: nanoid(), ...action.payload }];
    },
    
    // Action and reducer that clears all to-dos from the list
    todosCleared: (state) => {
      // Clears the to-do list by setting it to an empty array
      state.list = [];
    },
    
    // Action and reducer that deletes a to-do by its ID
    todoDeleted: (state, action) => {
      // Filters out the to-do with the matching ID from the list
      state.list = state.list.filter((todo) => todo.id !== action.payload);
    },
    
    // Action and reducer that toggles the visibility of the input form
    toggleInputForm: (state, action) => {
      // Toggles the visibility of the form (shows or hides it)
      state.toggleForm = !state.toggleForm;
      // Updates the todoUpdate state with any new data from the payload
      state.todoUpdate = { ...state.todoUpdate, ...action.payload };
    },
    
    // Action and reducer that updates an existing to-do's content and completed status
    todoUpdated: (state, action) => {
      // Finds the to-do to be updated using the ID from the payload
      const todoUpdate = state.list.find((todo) => todo.id === action.payload.id);
      if (todoUpdate) {
        // Updates the to-do's content and completed status
        todoUpdate.content = action.payload.content;
        todoUpdate.completed = action.payload.completed;
      }
      // Toggles the form visibility after an update
      state.toggleForm = !state.toggleForm;
    },
    
    // Action and reducer that toggles the completed status of a to-do
    todoToggled: (state, action) => {
      // Finds the to-do to be toggled using its ID
      const todoUpdate = state.list.find((todo) => todo.id === action.payload.id);
      if (todoUpdate) {
        // Flips the completed status (from true to false or vice versa)
        todoUpdate.completed = !todoUpdate.completed;
      }
    }
  },
});

// Export the actions for use in components (like adding or deleting to-dos)
export const {
  todoAdded,
  todosCleared,
  todoDeleted,
  toggleInputForm,
  todoUpdated,
  todoToggled
} = todoSlice.actions; 

// Export the reducer so it can be used to update the state in the Redux store
export default todoSlice.reducer;

// createSlice is used to create a slice of Redux state, combining both actions and reducers in one object. 
// This makes it easier to manage state changes for to-dos.

// The nanoid function generates unique IDs for new to-dos so that each to-do has a unique identifier.

// The initial state (initialState) defines the structure of the state when the app starts. It includes a list 
// of to-dos, a toggleForm flag to control form visibility, and a todoUpdate object to hold the to-do being edited.

// Each action in the reducers object corresponds to a specific operation on the to-do list (e.g., adding, deleting, 
// toggling, updating, clearing, or editing).

// The todoAdded action is used to add a new to-do, todoDeleted to remove a to-do, and todoToggled to flip the 
// completed status of a to-do.

// The toggleInputForm action toggles the visibility of the input form, and the todoUpdated action updates an 
// existing to-do's content and completion status.