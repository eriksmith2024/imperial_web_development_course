
// Import the StrictMode component from React. StrictMode is a wrapper that helps with identifying potential problems in an app during development. 
import { StrictMode } from "react";

// Import the createRoot method from react-dom/client. This method is used to create a root DOM node to render the React app.
import { createRoot } from "react-dom/client";

// Import the main App component where the application's UI is defined.
import App from "./App";

// Import styles for the app, typically stored in an index.css file.
import "./index.css";

// Import the store, which is the Redux store where the app's state is managed.
import store from "./store/store";

// Import the Provider component from react-redux. This component will wrap the app and give all child components access to the Redux store.
import { Provider } from "react-redux";

// This line renders the entire app to the DOM using the createRoot method.
// It first identifies the element with the id "root" in the HTML file where the app will be rendered.
createRoot(document.getElementById("root")).render(
  // Wrap the app in StrictMode to help with development, identifying potential problems.
  <StrictMode>
    {/* The Provider component makes the Redux store available to any nested components that need access to it. */}
    <Provider store={store}>
      {/* The main App component of the app. This is where the actual UI will be rendered. */}
      <App />
    </Provider>
  </StrictMode>
);
