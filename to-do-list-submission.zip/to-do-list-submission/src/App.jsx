// Import the Card component, which is used to render the to-do card in the app.
import Card from "./components/Card";

// Define the App component, which serves as the main UI component of the application.
function App() {
  return (
    // Main div element that wraps the entire layout.
    <div>
      {/* 
        The "container" class applies padding and centers the content horizontally.
        "mx-auto" centers the content horizontally within the container.
        "flex" applies Flexbox layout to position the children elements (Card in this case).
        "items-center" vertically centers the items within the flex container.
        "justify-center" horizontally centers the items within the flex container.
        "h-screen" sets the height of this container to be 100% of the viewport height (full screen).
      */}
      <div className="container mx-auto flex items-center justify-center h-screen">
        {/* The Card component is rendered here. It will be displayed in the center of the screen. */}
        <Card />
      </div>
    </div>
  );
}

// Export the App component to be used in other parts of the app, such as in the index.js file.
export default App;


// https://tailwindcss.com/docs/text-align Accessed 28th March 2025 to align placeholder and ammend size etc
// https://tailwindcss.com/docs/colors Tailwind guide Accessed 28th March - for color change  -  hover etc with tailwind
// https://tailwindcss.com/docs/responsive-design Tailwind guide Accessed 28th March - responsive sizing
// https://tailwindcss.com/docs/width Tailwind guide Accessed 28th March 2025 for width sizing 
// https://tailwindcss.com/docs/gap Tailwind guide Accessed 28th March 2025 for gap sizing
// https://tailwindcss.com/docs/text-align Tailwind guide accessed 28th March 2025 for text aligning
// https://tailwindcss.com/docs/align-self Tailwind guide accessed 28th March for alligning
// https://tailwindcss.com/docs/box-shadow Tailwind guide accessed 28th March for box shadow