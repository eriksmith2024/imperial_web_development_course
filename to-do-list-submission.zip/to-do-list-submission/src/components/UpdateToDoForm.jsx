// Import necessary functions from React and Redux
import { useState, useEffect } from "react";  // useState for managing local state, useEffect for side effects
import { useSelector, useDispatch } from "react-redux";  // useSelector to access state, useDispatch to dispatch actions
import { todoUpdated } from "../store/features/todo/todoSlice";  // Import the action to update a to-do
import Modal from "./Modal"; // Import Modal component for the form to appear in a popup

// Define the UpdateToDoForm component, which receives isOpen and onClose as props for controlling modal visibility
const UpdateToDoForm = ({ isOpen, onClose }) => {
  // Get the to-do that needs to be updated from the Redux store
  const todoUpdate = useSelector((state) => state.todos.todoUpdate); 
  // Set up local state for holding the to-do's updated content
  const [update, setUpdate] = useState(todoUpdate?.content || ""); 
  const dispatch = useDispatch(); // Initialize the dispatch function for dispatching actions

  // This effect runs when todoUpdate changes, updating the input field with the new to-do content
  useEffect(() => {
    if (todoUpdate) {
      setUpdate(todoUpdate.content); // Set the content in the input field
    }
  }, [todoUpdate]);  // Only run when todoUpdate changes

  // Function to handle form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent default form submission behavior (page reload)
    // Check if the input content is empty or just spaces
    if (/^\s*$/.test(update)) {  // regex checks for only spaces
      alert("Enter a valid todo"); // Show an alert if the input is invalid
      return;
    }
    // Dispatch the todoUpdated action to update the to-do in the Redux store
    dispatch(
      todoUpdated({
        id: todoUpdate.id,  // Use the ID of the to-do being updated
        content: update,    // Use the updated content from the input
        completed: todoUpdate.completed, // Keep the completed status the same
      })
    );
    onClose(); // Close the modal after submitting the update
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <h2 className="text-xl font-bold mb-4">Edit To-Do</h2>
      <form onSubmit={handleSubmit} className="flex flex-col space-y-3">
        <input
          value={update} // Set the input value to the update state
          onChange={(e) => setUpdate(e.target.value)} // Update the local state when user types
          type="text"
          className="border p-2 rounded w-full"
          placeholder="Edit your to-do"
        />
        <div className="flex justify-end space-x-2">
          <button
            type="button"
            onClick={onClose} // Close the modal without saving any changes
            className="bg-gray-400 text-white py-2 px-4 rounded"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="bg-orange-500 text-white py-2 px-4 rounded"
          >
            Save
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default UpdateToDoForm;



//Important tip type rafce to get a template  refer to SingleTodoCard.jsx for example of the template it generates.

// https://tailwindcss.com/docs/text-align Accessed 28th March 2025 to align placeholder and ammend size etc
// https://tailwindcss.com/docs/colors Tailwind guide Accessed 28th March - for color change  -  hover etc with tailwind
// https://tailwindcss.com/docs/responsive-design Tailwind guide Accessed 28th March - responsive sizing
// https://tailwindcss.com/docs/width Tailwind guide Accessed 28th March 2025 for width sizing 
// https://tailwindcss.com/docs/gap Tailwind guide Accessed 28th March 2025 for gap sizing
// https://tailwindcss.com/docs/text-align Tailwind guide accessed 28th March 2025 for text aligning
// https://tailwindcss.com/docs/align-self Tailwind guide accessed 28th March for alligning
// https://tailwindcss.com/docs/box-shadow Tailwind guide accessed 28th March for box shadow
