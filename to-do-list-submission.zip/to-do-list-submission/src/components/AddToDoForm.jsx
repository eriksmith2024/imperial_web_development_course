// Importing useState hook to manage local state in the component
import { useState } from "react";
// Importing useDispatch hook from Redux to dispatch actions
import { useDispatch } from "react-redux";
// Importing the todoAdded action to add a new to-do to the state
import { todoAdded } from "../store/features/todo/todoSlice";
// Importing the Modal component to display the form inside a modal
import Modal from "./Modal"; 

// The AddToDoForm component takes two props: isOpen (whether the modal is open) and onClose (function to close the modal)
const AddToDoForm = ({ isOpen, onClose }) => {
  // State to store the input value (new to-do content)
  const [todo, setTodo] = useState("");
  // State to store any error message if the input is invalid
  const [error, setError] = useState(""); 
  // Accessing the dispatch function from Redux to dispatch actions
  const dispatch = useDispatch();

  // Function to handle the form submission
  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the default form submission behavior refreshing page
    // Check if the input is empty or only spaces
    if (/^\s*$/.test(todo)) {// standard expression for checking spaces or empty characters
      setError("Please enter a valid to-do."); // Set error message if input is invalid
      return;
    } else {
      // Dispatch the todoAdded action to add the new to-do to the state
      dispatch(todoAdded({ content: todo, completed: false }));
      setTodo(""); // Clear the input field after submission
      setError(""); // Clear any error message after successful submission
      onClose(); // Close the modal after adding the to-do
    }
  };

  return (
    // Modal component to display the form inside a modal
    <Modal isOpen={isOpen} onClose={onClose}>
      <h2 className="text-xl font-bold mb-4">Add a New To-Do</h2>
      {/* Form to add a new to-do */}
      <form onSubmit={handleSubmit} className="flex flex-col space-y-3">
        <input
          value={todo} // Bind the input value to the `todo` state
          onChange={(e) => {
            setTodo(e.target.value); // Update the `todo` state as the user types
            setError(""); // Clear error message as user types
          }}
          type="text" // Input type is text
          className="border p-2 rounded w-full" // Tailwind CSS styling for the input field
          placeholder="Enter a new to-do" // Placeholder text for the input field
        />
        {/* Display the error message if there's an error */}
        {error && <p className="text-red-500 text-sm">{error}</p>} 

        <div className="flex justify-end space-x-2 mt-4">
          {/* Cancel button to close the modal without submitting the form */}
          <button
            type="button"
            onClick={onClose} // Close the modal when clicked
            className="bg-gray-400 text-white py-2 px-4 rounded"
          >
            Cancel
          </button>
          {/* Submit button to add the new to-do */}
          <button
            type="submit" // Submit the form when clicked
            className="bg-blue-500 text-white py-2 px-4 rounded"
          >
            Add
          </button>
        </div>
      </form>
    </Modal>
  );
};

// Exporting the AddToDoForm component to use it in other parts of the app
export default AddToDoForm;


// https://tailwindcss.com/docs/text-align Accessed 28th March 2025 to align placeholder and ammend size etc
// https://tailwindcss.com/docs/colors Tailwind guide Accessed 28th March - for color change  -  hover etc with tailwind
// https://tailwindcss.com/docs/responsive-design Tailwind guide Accessed 28th March - responsive sizing
// https://tailwindcss.com/docs/width Tailwind guide Accessed 28th March 2025 for width sizing 
// https://tailwindcss.com/docs/gap Tailwind guide Accessed 28th March 2025 for gap sizing
// https://tailwindcss.com/docs/text-align Tailwind guide accessed 28th March 2025 for text aligning
// https://tailwindcss.com/docs/align-self Tailwind guide accessed 28th March for alligning
// https://tailwindcss.com/docs/box-shadow Tailwind guide accessed 28th March for box shadow