// Import necessary functions and components
import { useState } from "react"; // useState hook for managing state
import { useSelector, useDispatch } from "react-redux"; // useSelector to get state, useDispatch to send actions
import { BsInfoCircle } from "react-icons/bs"; // Import Info icon from react-icons
import AddToDoForm from "./AddToDoForm"; // Import AddToDoForm component
import UpdateToDoForm from "./UpdateToDoForm"; // Import UpdateToDoForm component
import SingleTodoCard from "./SingleTodoCard"; // Import SingleTodoCard component
import { todosCleared } from "../store/features/todo/todoSlice"; // Import action to clear all todos

const Card = () => {
  // State hooks to manage modal visibility
  const [isModalOpen, setModalOpen] = useState(false); // Manage the modal for adding a new to-do
  const [isInfoModalOpen, setInfoModalOpen] = useState(false); // Manage the info modal visibility

  // Retrieve necessary data from the Redux store
  const myTodos = useSelector((state) => state.todos.list); // Get the list of to-dos
  const toggleForm = useSelector((state) => state.todos.toggleForm); // Controls whether the Add or Update form is shown
  const todoUpdate = useSelector((state) => state.todos.todoUpdate); // Get the to-do currently being updated
  const dispatch = useDispatch(); // Get the dispatch function for sending actions to Redux store

  // Function to close the info modal
  const closeInfoModal = () => setInfoModalOpen(false);

  return (
    <div className="w-11/12 md:w-1/2 h-3/4 bg-indigo-300 shadow-2xl rounded-lg p-4 flex flex-col relative">
      {/* Purple Card with shadow and padding */}
      
      {/* Button to open the info modal, placed at the top right */}
      <div className="absolute top-4 right-4 cursor-pointer z-10" onClick={() => setInfoModalOpen(true)}>
        <BsInfoCircle size={30} className="text-white" /> {/* Info icon */}
      </div>

      {/* Main content of the card */}
      <div className="flex flex-col space-y-10 w-full h-3/4 min-h-max items-center">
        {/* Heading displaying the number of to-dos */}
        <h1 className="text-3xl font-semibold underline">
          My To Do List ({myTodos.length})
        </h1>

        {/* Form to add or update to-dos based on toggleForm */}
        <div className="w-3/4">
          {toggleForm ? <AddToDoForm /> : <UpdateToDoForm isOpen={true} onClose={() => dispatch({ type: 'todoSlice/toggleForm' })} />}
        </div>

        {/* List of all to-dos displayed in individual cards */}
        <div className="w-3/4">
          <ul className="w-full max-h-72 overflow-y-scroll">
            {myTodos.map((todo) => (
              <li className="mb-3" key={todo.id}>
                <SingleTodoCard
                  id={todo.id}
                  content={todo.content}
                  completed={todo.completed}
                />
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Button to clear all to-dos */}
      <div className="flex-grow"></div>

      <button
        onClick={() => dispatch(todosCleared())} // Dispatch action to clear all to-dos
        className="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-6 rounded focus:outline-none focus:shadow-outline self-center mb-4"
      >
        Clear All
      </button>

      {/* Button to open the modal for adding a new to-do */}
      <button
        onClick={() => setModalOpen(true)} // Open the add to-do modal
        className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-6 rounded focus:outline-none focus:shadow-outline self-center"
      >
        Add New To-Do
      </button>

      {/* Info Modal */}
      {isInfoModalOpen && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-96">
            <h2 className="text-xl font-semibold mb-4">User Instructions</h2>
            <p className="text-sm mb-4">
              Here are some instructions for using the To-Do app:
              <ul>
                <li>Click the "Add New To-Do" button to add a new to-do item.</li>
                <li>Click the "Clear All" button to delete all to-do items.</li>
                <li>Click on a to-do to mark it as completed or edit it.</li>
              </ul>
            </p>
            {/* Button to close the info modal */}
            <button
              onClick={closeInfoModal} // Close the info modal
              className="bg-red-500 text-white font-bold py-2 px-4 rounded"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Modal for adding a new to-do */}
      <AddToDoForm isOpen={isModalOpen} onClose={() => setModalOpen(false)} />
    </div>
  );
};

export default Card;


