// Define the Modal component which takes 'isOpen', 'onClose', and 'children' as props
const Modal = ({ isOpen, onClose, children }) => {
    // If 'isOpen' is false, don't render anything (return null)
    if (!isOpen) return null;
    
    // If 'isOpen' is true, render the modal
    return (
      // Outer container for the modal, with a semi-transparent background and centered content
      <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
        {/* Inner modal box with white background, padding, rounded corners, and shadow */}
        <div className="bg-white p-6 rounded-lg shadow-lg w-1/3">
          {/* Close button positioned at the top right corner, when clicked it calls onClose */}
          <button
            className="absolute top-4 right-4 text-gray-700 text-xl"
            onClick={onClose} // Calls the onClose function to close the modal
          >
            ✖
          </button>
          {/* Display any content passed as 'children' inside the modal */}
          {children}
        </div>
      </div>
    );
  };
  
  // Export the Modal component to be used in other parts of the application
  export default Modal;
  
  