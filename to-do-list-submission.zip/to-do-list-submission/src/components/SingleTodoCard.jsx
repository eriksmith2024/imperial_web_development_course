// Importing specific icons from the react-icons library
import { BsTrashFill, BsCheckSquare } from "react-icons/bs"; // Trash and check icons from Bootstrap Icons
import { FaEdit } from "react-icons/fa"; // Edit icon from Font Awesome

// Importing Redux actions to handle deleting, toggling, and editing to-dos
import { todoDeleted, toggleInputForm, todoToggled } from "../store/features/todo/todoSlice";

// Importing the `useDispatch` hook from Redux to dispatch actions
import { useDispatch } from "react-redux";

// Defining the SingleTodoCard functional component that takes `props` as input
const SingleTodoCard = (props) => {
  // Getting the dispatch function from Redux to send actions
  const dispatch = useDispatch();

  // Function to handle the click event for editing a to-do
  const handleEditClick = () => {
    // Only allow editing if the task is not completed
    if (!props.completed) {
      // Dispatch the action to toggle the input form, sending the to-do details
      dispatch(
        toggleInputForm({
          id: props.id, // Pass the to-do ID
          content: props.content, // Pass the to-do content
          completed: props.completed, // Pass the completion status
        })
      );
    }
  };

  return (
    // Outer div for styling the card, with flex layout, rounded corners, and shadow effect
    <div className="flex justify-between bg-red-100 py-2 rounded shadow">
      <div className="px-4">
        {/* To-Do content, with conditional opacity for completed tasks */}
        <h1 className={`font-semibold ${props.completed ? 'opacity-50' : ''}`} style={{ transition: 'opacity 0.3s ease' }}>
          {props.content} {/* Display the to-do content */}
        </h1>
      </div>
      <div className="px-4 flex space-x-4">
        {/* Checkbox icon to toggle the completion status */}
        <BsCheckSquare
          onClick={() => dispatch(todoToggled({ id: props.id }))} // Dispatch action to toggle completion
          className="cursor-pointer text-green-700" // Style the icon to be green
          size={20} // Set the icon size
        />
        {/* Edit icon to open the input form for editing */}
        <FaEdit
          onClick={handleEditClick} // Call handleEditClick when clicked
          className={`cursor-pointer ${props.completed ? 'text-gray-400' : 'text-yellow-700'}`} // Change color if completed
          size={20} // Set the icon size
          style={{ pointerEvents: props.completed ? 'none' : 'auto' }} // Disable editing if task is completed
        />
        {/* Trash icon to delete the to-do */}
        <BsTrashFill
          onClick={() => dispatch(todoDeleted(props.id))} // Dispatch action to delete the to-do
          className="cursor-pointer text-yellow-700" // Style the icon to be yellow
          size={20} // Set the icon size
        />
      </div>
    </div>
  );
};

// Exporting the SingleTodoCard component to be used in other parts of the app
export default SingleTodoCard;


// https://www.npmjs.com/package/react-icons

//Important tip type rafce to get a template see below template it generates in empty SingleTodoCard.jsx file
// import React from 'react';

// const SingleTodoCard = () => {
//   return (
//     <div>

//     </div>
//   );
// }

// export default SingleTodoCard;